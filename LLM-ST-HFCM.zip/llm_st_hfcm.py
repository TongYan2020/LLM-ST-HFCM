import time
import math
import torch
import torch.nn as nn
import numpy as np
import pandas as pd
from torch.utils.data import DataLoader, TensorDataset
from utils.metrics import calculate_metrics


class Sparsemax(nn.Module):
    def __init__(self, dim=-1):
        super(Sparsemax, self).__init__()
        self.dim = dim

    def forward(self, input_tensor):
        original_shape = input_tensor.shape
        input_tensor = input_tensor.transpose(self.dim, -1)
        flat_input = input_tensor.reshape(-1, input_tensor.size(-1))
        sorted_input, _ = torch.sort(flat_input, descending=True, dim=-1)
        cumsum = torch.cumsum(sorted_input, dim=-1)
        arange = torch.arange(1, input_tensor.size(-1) + 1, device=input_tensor.device, dtype=input_tensor.dtype)
        cond = 1 + arange * sorted_input > cumsum

        k_selected = torch.max(cond * arange, dim=-1, keepdim=True)[0]
        cumsum_k = torch.gather(cumsum, dim=-1, index=(k_selected - 1).long())
        threshold = (cumsum_k - 1) / k_selected.to(input_tensor.dtype)

        output = torch.clamp(flat_input - threshold, min=0)
        output = output.reshape(original_shape[:-1] + (original_shape[-1],))
        output = output.transpose(self.dim, -1)
        return output


class LLM_ST_HFCM_Net(nn.Module):
    def __init__(self, num_vars, order_k, tau, w_prior, dim_h=32, dim_k=32, dim_a=32):
        super(LLM_ST_HFCM_Net, self).__init__()
        self.num_vars = num_vars
        self.order_k = order_k  # K_max
        self.tau = tau
        self.register_buffer('w_prior', torch.as_tensor(w_prior, dtype=torch.float32))
        self.phi = nn.Linear(tau, dim_h)
        self.W_Q = nn.Linear(dim_h, dim_k, bias=False)
        self.W_K = nn.Linear(dim_h, dim_k, bias=False)
        self.gamma_raw = nn.Parameter(torch.zeros(num_vars, num_vars))
        self.W_aq = nn.Linear(dim_k, dim_a, bias=False)
        self.W_ak = nn.Linear(dim_k, dim_a, bias=False)
        self.b_a = nn.Parameter(torch.zeros(dim_a))
        self.v_a = nn.Linear(dim_a, 1, bias=False)
        self.sparsemax = Sparsemax(dim=-1)
        self.v_p = nn.Linear(2 * dim_h, 1, bias=False)
        self.b_p = nn.Parameter(torch.zeros(1))

    def forward(self, x):
        batch_size = x.size(0)
        x_unfolded = x.unfold(1, self.tau, 1).permute(0, 3, 1, 2)
        h = torch.relu(self.phi(x_unfolded))
        h_target_curr = h[:, :, -1, :]
        q = self.W_Q(h_target_curr)
        k = self.W_K(h)
        s = torch.einsum('bjd,bikd->bijk', q, k) / math.sqrt(q.size(-1))
        gamma = torch.sigmoid(self.gamma_raw)
        prior_strength_bias = (gamma * torch.abs(self.w_prior)).unsqueeze(-1)
        s_tilde = s + prior_strength_bias
        a = torch.sigmoid(s_tilde)
        h_source = h.unsqueeze(2).expand(-1, -1, self.num_vars, -1, -1)
        h_target = h_target_curr.unsqueeze(1).unsqueeze(3).expand(-1, self.num_vars, -1, self.order_k, -1)
        h_concat_p = torch.cat([h_source, h_target], dim=-1)
        p_raw = self.v_p(h_concat_p).squeeze(-1)
        prior_polarity_bias = (gamma * self.w_prior).unsqueeze(-1)
        p = torch.tanh(p_raw + prior_polarity_bias + self.b_p)
        w = a * p
        q_proj = self.W_aq(q).unsqueeze(1).unsqueeze(3)
        k_proj = self.W_ak(k).unsqueeze(2)
        u_hidden = torch.tanh(q_proj + k_proj + self.b_a)
        u = self.v_a(u_hidden).squeeze(-1)
        alpha = self.sparsemax(u)
        x_history = x[:, self.tau - 1:, :].transpose(1, 2)
        effective_w = alpha * w
        evolution_input = torch.einsum('bijk,bik->bj', effective_w, x_history)
        predictions = torch.sigmoid(evolution_input)
        return predictions, w, p, alpha


def create_joint_loss(predictions, targets, alpha, w, p, w_prior, lambda_1, lambda_2):
    loss_pred = nn.MSELoss()(predictions, targets)
    loss_sparse = torch.mean(torch.abs(alpha * w))
    hinge_loss = torch.clamp(- w_prior.unsqueeze(0).unsqueeze(-1) * p, min=0)
    loss_align = torch.mean(alpha * hinge_loss)
    total_loss = loss_pred + lambda_1 * loss_sparse + lambda_2 * loss_align
    return total_loss, loss_pred, loss_sparse, loss_align


def create_sliding_windows_st(data, order_k, tau):
    window_size = order_k + tau - 1
    X, Y = [], []
    for i in range(len(data) - window_size):
        X.append(data[i: i + window_size])
        Y.append(data[i + window_size])
    return np.array(X), np.array(Y)


def run_llm_st_hfcm(file_path, prior_path, order_k, tau, lambda_1, lambda_2, **train_cfg):
    device = train_cfg.get('device', torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    """
    To protect the originality of our work during the review process, only the core code is provided at this time.
    """
    train_loader, (X_test_t, Y_test), scaler = prepare_data_and_loaders(
        file_path, order_k=order_k, tau=tau, batch_size=train_cfg.get('batch_size', 32)
    )
    w_prior = load_prior_matrix(prior_path)

    model = LLM_ST_HFCM_Net(
        num_vars=Y_test.shape[1], order_k=order_k, tau=tau, w_prior=w_prior
    ).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=train_cfg.get('lr', 0.003), weight_decay=1e-4)

    history_loss, fit_time = train_joint_model(
        model, train_loader, optimizer, lambda_1, lambda_2, **train_cfg
    )

    metrics, Y_test, preds, (w_t, p_t, alpha_t) = evaluate_hfcm(
        model, X_test_t, Y_test, scaler, run_time=fit_time
    )

    return metrics, Y_test, preds, w_t, p_t, alpha_t, history_loss
