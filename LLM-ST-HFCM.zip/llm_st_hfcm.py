"""Forecasting model with precomputed priors; axes [batch, lag, source, target]."""
import math
import torch
from torch import nn
from .constraints import validate_lag_parameters
from .ablation_protocol import ABLATIONS, ablation_settings


def sparsemax(z, dim=1):
    z = z - z.max(dim=dim, keepdim=True).values
    ordered = z.sort(dim=dim, descending=True).values
    shape = [1] * z.ndim
    shape[dim] = z.shape[dim]
    rank = torch.arange(1, z.shape[dim]+1, device=z.device, dtype=z.dtype).view(shape)
    cumulative = ordered.cumsum(dim)
    support = 1 + rank * ordered > cumulative
    count = support.sum(dim=dim, keepdim=True).clamp_min(1)
    threshold = (cumulative.gather(dim, count-1) - 1) / count
    return (z-threshold).clamp_min(0)


class LLMSTHFCM(nn.Module):
    def __init__(self, n, prior, k, tau, hidden, attention,
                 lambda1, lambda2, temporal='sparsemax',
                 temporal_activation='tanh', no_prior=False, static_spatial=False,
                 fixed_gate=False, enforce_k_ge_tau=True, static_spatial_mode='legacy_table',
                 fixed_gate_value=.5, **unused):
        super().__init__()
        validate_lag_parameters(k, tau, unused.get('lookback'), enforce_k_ge_tau=enforce_k_ge_tau)
        self.k, self.tau = k, tau
        self.lambda1, self.lambda2 = lambda1, lambda2
        self.temporal, self.temporal_activation = temporal, temporal_activation
        self.static_spatial, self.fixed_gate = static_spatial, fixed_gate
        self.static_spatial_mode, self.fixed_gate_value = static_spatial_mode, fixed_gate_value
        self.register_buffer('prior', torch.as_tensor(prior, dtype=torch.float32).clone())
        if no_prior:
            self.prior.zero_()
            self.lambda2 = 0.
        self.phi = nn.Linear(tau, hidden)
        self.query = nn.Linear(hidden, attention, bias=False)
        self.key = nn.Linear(hidden, attention, bias=False)
        self.aq = nn.Linear(attention, attention, bias=False)
        self.ak = nn.Linear(attention, attention, bias=True)
        self.va = nn.Linear(attention, 1, bias=False)
        self.ps = nn.Linear(hidden, 1, bias=False)
        self.pt = nn.Linear(hidden, 1, bias=True)
        self.gate = nn.Parameter(torch.zeros(n, n), requires_grad=not (fixed_gate or no_prior))
        

    def forward(self, x):
        h = self.phi(x.unfold(1, self.tau, 1)[:, -self.k:].flip(1)).relu()
        target = h[:, 0]
        q, key = self.query(target), self.key(h)
        score = torch.einsum('bja,bdia->bdij', q, key) / math.sqrt(q.shape[-1])
        z = self.aq(q)[:, None, None, :, :] + self.ak(key)[:, :, :, None, :]
        nonlinear = torch.tan(z) if self.temporal_activation == 'tan' else torch.tanh(z)
        u = self.va(nonlinear).squeeze(-1)
        alpha = u.softmax(1) if self.temporal == 'softmax' else sparsemax(u, 1)
        gate = torch.full_like(self.gate, self.fixed_gate_value) if self.fixed_gate else self.gate.sigmoid()
        strength = (score + gate * self.prior.abs()).sigmoid()
        polarity = (self.ps(h).squeeze(-1)[:, :, :, None]
                    + self.pt(target).squeeze(-1)[:, None, None, :]
                    + gate * self.prior).tanh()
        effective = alpha * strength * polarity
        states = x[:, -self.k:].flip(1)
        prediction = torch.einsum('bdij,bdi->bj', effective, states).sigmoid()
        prior_loss = (alpha * (-self.prior * polarity).relu()).mean()
        return prediction, {'effective': effective, 'alpha': alpha,
                            'sparse': effective.abs().mean(), 'prior': prior_loss}

    def objective(self, prediction, y, info):
        data = (prediction-y).square().mean()
        return data+self.lambda1*info['sparse']+self.lambda2*info['prior'], data
