def normalize_polarity(value: Any) -> str:
    s = str(value or "").strip().lower().replace("_", " ").replace("-", " ")
    mapping = {
        "promoting": "Promoting",
        "promote": "Promoting",
        "promotion": "Promoting",
        "positive": "Promoting",
        "+1": "Promoting",
        "inhibiting": "Inhibiting",
        "inhibit": "Inhibiting",
        "inhibition": "Inhibiting",
        "negative": "Inhibiting",
        "-1": "Inhibiting",
        "none": "None",
        "no effect": "None",
        "no direct effect": "None",
        "0": "None",
        "unknown": "Unknown",
        "uncertain": "Unknown",
        "ambiguous": "Unknown",
    }
    return mapping.get(s, "Unknown")


def stage1_prompts(ds: Dataset, pairs: Sequence[Tuple[str, str]]) -> Tuple[str, str]:
    system = f"""You are a senior domain expert in {ds.domain}.
Your task is to extract signed semantic priors from variable definitions. These are qualitative hypotheses, NOT a causal graph and NOT ground truth.
Judge direct, immediate directional effects only. Exclude indirect paths, mere correlation, common causes, temporal co-occurrence, and speculative mechanisms. Prefer None or Unknown over an unsupported signed link.
Polarity semantics: Promoting = an increase/change in source directly tends to increase/strengthen target under the stated variable meanings; Inhibiting = it directly tends to decrease/weaken target; None = no direct effect is supported; Unknown = the descriptions/domain knowledge are insufficient or materially ambiguous.
Return JSON only and follow the requested schema exactly."""

    user = {
        "domain": ds.domain,
        "variables": variable_payload(ds),
        "requested_directed_pairs": [
            {"source": a, "target": b} for a, b in pairs
        ],
        "instructions": [
            "Consider the full variable list as global context.",
            "Classify every requested directed pair exactly once.",
            "Do not infer a link just because the variables are correlated.",
            "For each pair provide source, target, polarity, and one concise justification.",
            "Allowed polarity values are exactly: Promoting, Inhibiting, None, Unknown.",
        ],
        "output_schema": {
            "relations": [
                {
                    "source": "exact variable name",
                    "target": "exact variable name",
                    "polarity": "Promoting|Inhibiting|None|Unknown",
                    "justification": "concise direct-mechanism rationale",
                }
            ]
        },
    }
    return system, json.dumps(user, ensure_ascii=False, indent=2)


def stage2_prompts(ds: Dataset, rel: Dict[str, Any]) -> Tuple[str, str]:
    source, target = rel["source"], rel["target"]
    system = """You are a rigorous logical reasoning agent.
Evaluate whether a proposed signed semantic relation is a defensible DIRECT relation. Reject links that are indirect, ambiguous, merely correlational, depend on an unstated mediator, or have the wrong sign.
Do not reveal or reproduce private chain-of-thought. Instead, return a concise, auditable mechanism summary supporting the final judgment.
Return JSON only."""
    user = {
        "domain": ds.domain,
        "source": {"name": source, "description": ds.descriptions[source]},
        "target": {"name": target, "description": ds.descriptions[target]},
        "proposed_polarity": rel["stage1_polarity"],
        "verification_checks": [
            "Identify the intrinsic roles of source and target from their definitions.",
            "Check whether a direct mechanism exists without relying on another variable as mediator.",
            "Check whether the direct sign agrees with the proposed polarity.",
            "If directness/sign is ambiguous or contradictory, mark valid=false.",
        ],
        "output_schema": {
            "valid": True,
            "polarity": "Promoting|Inhibiting|None|Unknown",
            "explanation": "concise mechanism summary; no hidden chain-of-thought",
        },
    }
    return system, json.dumps(user, ensure_ascii=False, indent=2)


def stage3_prompts(ds: Dataset, rel: Dict[str, Any]) -> Tuple[str, str]:
    source, target = rel["source"], rel["target"]
    system = f"""You are a senior domain expert in {ds.domain}.
This is an independent, context-isolated assessment. You have no access to, and must not assume, any previous judgment.
Based only on the domain and the two variable definitions, classify the DIRECT directional relationship from source to target as Promoting, Inhibiting, None, or Unknown. Exclude indirect links and correlation-only claims.
Return JSON only."""
    user = {
        "domain": ds.domain,
        "source": {"name": source, "description": ds.descriptions[source]},
        "target": {"name": target, "description": ds.descriptions[target]},
        "output_schema": {
            "polarity": "Promoting|Inhibiting|None|Unknown",
            "explanation": "short independent justification",
        },
    }
    return system, json.dumps(user, ensure_ascii=False, indent=2)